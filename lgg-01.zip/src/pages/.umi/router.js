import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from '/Users/jifa/work/webapp/Lgg/src/pages/.umi/LocaleWrapper.jsx'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/user",
    "redirect": "/user/login",
    "exact": true
  },
  {
    "path": "/",
    "redirect": "/questiontype",
    "exact": true
  },
  {
    "path": "/user",
    "component": dynamic({ loader: () => import('../../layouts/UserLayout'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
    "routes": [
      {
        "path": "/user/login",
        "component": dynamic({ loader: () => import('../User/Login'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/user/register",
        "component": dynamic({ loader: () => import('../User/Register'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/user/register-result",
        "component": dynamic({ loader: () => import('../User/RegisterResult'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "component": () => React.createElement(require('/Users/jifa/work/webapp/Lgg/node_modules/_umi-build-dev@1.0.1@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/",
    "component": dynamic({ loader: () => import('../../layouts/BasicLayout'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
    "Routes": [require('../Authorized').default],
    "routes": [
      {
        "path": "/questiontype",
        "name": "questiontype",
        "icon": "question-circle",
        "component": dynamic({ loader: () => import('../Questiontype/index'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/question",
        "name": "question",
        "icon": "ordered-list",
        "component": dynamic({ loader: () => import('../Question/index'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/answer",
        "name": "answer",
        "icon": "radar-chart",
        "component": dynamic({ loader: () => import('../Answer/index'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/scorerule",
        "name": "scorerule",
        "icon": "setting",
        "component": dynamic({ loader: () => import('../Scorerule/index'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/trade",
        "name": "trade",
        "icon": "solution",
        "component": dynamic({ loader: () => import('../Trade/index'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/paytrade",
        "name": "paytrade",
        "icon": "shop",
        "component": dynamic({ loader: () => import('../Paytrade/index'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/vip",
        "name": "vip",
        "icon": "user",
        "component": dynamic({ loader: () => import('../Vip/index'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "path": "/oper",
        "name": "oper",
        "icon": "key",
        "component": dynamic({ loader: () => import('../Oper/index'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "component": dynamic({ loader: () => import('../404'), loading: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default  }),
        "exact": true
      },
      {
        "component": () => React.createElement(require('/Users/jifa/work/webapp/Lgg/node_modules/_umi-build-dev@1.0.1@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('/Users/jifa/work/webapp/Lgg/node_modules/_umi-build-dev@1.0.1@umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];

export default function() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
