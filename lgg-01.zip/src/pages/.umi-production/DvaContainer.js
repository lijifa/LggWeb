import { Component } from 'react';
import dva from 'dva';
import createLoading from 'dva-loading';

let app = dva({
  history: window.g_history,
  
});

window.g_app = app;
app.use(createLoading());

app.model({ namespace: 'batchAddSysparam', ...(require('/Users/jifa/work/webapp/Lgg/src/models/batchAddSysparam.js').default) });
app.model({ namespace: 'card', ...(require('/Users/jifa/work/webapp/Lgg/src/models/card.js').default) });
app.model({ namespace: 'cardtype', ...(require('/Users/jifa/work/webapp/Lgg/src/models/cardtype.js').default) });
app.model({ namespace: 'changeCard', ...(require('/Users/jifa/work/webapp/Lgg/src/models/changeCard.js').default) });
app.model({ namespace: 'dept', ...(require('/Users/jifa/work/webapp/Lgg/src/models/dept.js').default) });
app.model({ namespace: 'district', ...(require('/Users/jifa/work/webapp/Lgg/src/models/district.js').default) });
app.model({ namespace: 'employee', ...(require('/Users/jifa/work/webapp/Lgg/src/models/employee.js').default) });
app.model({ namespace: 'employee1', ...(require('/Users/jifa/work/webapp/Lgg/src/models/employee1.js').default) });
app.model({ namespace: 'global', ...(require('/Users/jifa/work/webapp/Lgg/src/models/global.js').default) });
app.model({ namespace: 'home', ...(require('/Users/jifa/work/webapp/Lgg/src/models/home.js').default) });
app.model({ namespace: 'item', ...(require('/Users/jifa/work/webapp/Lgg/src/models/item.js').default) });
app.model({ namespace: 'itemgrp', ...(require('/Users/jifa/work/webapp/Lgg/src/models/itemgrp.js').default) });
app.model({ namespace: 'itemtag', ...(require('/Users/jifa/work/webapp/Lgg/src/models/itemtag.js').default) });
app.model({ namespace: 'job', ...(require('/Users/jifa/work/webapp/Lgg/src/models/job.js').default) });
app.model({ namespace: 'joblevel', ...(require('/Users/jifa/work/webapp/Lgg/src/models/joblevel.js').default) });
app.model({ namespace: 'lockcard', ...(require('/Users/jifa/work/webapp/Lgg/src/models/lockcard.js').default) });
app.model({ namespace: 'login', ...(require('/Users/jifa/work/webapp/Lgg/src/models/login.js').default) });
app.model({ namespace: 'mealsection', ...(require('/Users/jifa/work/webapp/Lgg/src/models/mealsection.js').default) });
app.model({ namespace: 'menu', ...(require('/Users/jifa/work/webapp/Lgg/src/models/menu.js').default) });
app.model({ namespace: 'menunotice', ...(require('/Users/jifa/work/webapp/Lgg/src/models/menunotice.js').default) });
app.model({ namespace: 'mer', ...(require('/Users/jifa/work/webapp/Lgg/src/models/mer.js').default) });
app.model({ namespace: 'notice', ...(require('/Users/jifa/work/webapp/Lgg/src/models/notice.js').default) });
app.model({ namespace: 'noticetemplate', ...(require('/Users/jifa/work/webapp/Lgg/src/models/noticetemplate.js').default) });
app.model({ namespace: 'oper', ...(require('/Users/jifa/work/webapp/Lgg/src/models/oper.js').default) });
app.model({ namespace: 'organ', ...(require('/Users/jifa/work/webapp/Lgg/src/models/organ.js').default) });
app.model({ namespace: 'param', ...(require('/Users/jifa/work/webapp/Lgg/src/models/param.js').default) });
app.model({ namespace: 'project', ...(require('/Users/jifa/work/webapp/Lgg/src/models/project.js').default) });
app.model({ namespace: 'question', ...(require('/Users/jifa/work/webapp/Lgg/src/models/question.js').default) });
app.model({ namespace: 'questiontype', ...(require('/Users/jifa/work/webapp/Lgg/src/models/questiontype.js').default) });
app.model({ namespace: 'rchg', ...(require('/Users/jifa/work/webapp/Lgg/src/models/rchg.js').default) });
app.model({ namespace: 'returncard', ...(require('/Users/jifa/work/webapp/Lgg/src/models/returncard.js').default) });
app.model({ namespace: 'role', ...(require('/Users/jifa/work/webapp/Lgg/src/models/role.js').default) });
app.model({ namespace: 'rolemodule', ...(require('/Users/jifa/work/webapp/Lgg/src/models/rolemodule.js').default) });
app.model({ namespace: 'score', ...(require('/Users/jifa/work/webapp/Lgg/src/models/score.js').default) });
app.model({ namespace: 'scoreRule', ...(require('/Users/jifa/work/webapp/Lgg/src/models/scoreRule.js').default) });
app.model({ namespace: 'setting', ...(require('/Users/jifa/work/webapp/Lgg/src/models/setting.js').default) });
app.model({ namespace: 'shop', ...(require('/Users/jifa/work/webapp/Lgg/src/models/shop.js').default) });
app.model({ namespace: 'tempcardauth', ...(require('/Users/jifa/work/webapp/Lgg/src/models/tempcardauth.js').default) });
app.model({ namespace: 'trade', ...(require('/Users/jifa/work/webapp/Lgg/src/models/trade.js').default) });
app.model({ namespace: 'unlockCard', ...(require('/Users/jifa/work/webapp/Lgg/src/models/unlockCard.js').default) });
app.model({ namespace: 'user', ...(require('/Users/jifa/work/webapp/Lgg/src/models/user.js').default) });
app.model({ namespace: 'vip', ...(require('/Users/jifa/work/webapp/Lgg/src/models/vip.js').default) });

class DvaContainer extends Component {
  render() {
    app.router(() => this.props.children);
    return app.start()();
  }
}

export default DvaContainer;
