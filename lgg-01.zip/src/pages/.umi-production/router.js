import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from '/Users/jifa/work/webapp/Lgg/src/pages/.umi-production/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/user",
    "redirect": "/user/login",
    "exact": true
  },
  {
    "path": "/",
    "redirect": "/questiontype",
    "exact": true
  },
  {
    "path": "/user",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/UserLayout'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
    "routes": [
      {
        "path": "/user/login",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/jifa/work/webapp/Lgg/src/pages/User/models/register.js')
],
  component: () => import('../User/Login'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/user/register",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/jifa/work/webapp/Lgg/src/pages/User/models/register.js')
],
  component: () => import('../User/Register'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/user/register-result",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/jifa/work/webapp/Lgg/src/pages/User/models/register.js')
],
  component: () => import('../User/RegisterResult'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      }
    ]
  },
  {
    "path": "/",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/BasicLayout'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
    "Routes": [require('../Authorized').default],
    "routes": [
      {
        "path": "/questiontype",
        "name": "questiontype",
        "icon": "question-circle",
        "component": _dvaDynamic({
  
  component: () => import('../Questiontype/index'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/question",
        "name": "question",
        "icon": "ordered-list",
        "component": _dvaDynamic({
  
  component: () => import('../Question/index'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/answer",
        "name": "answer",
        "icon": "radar-chart",
        "component": _dvaDynamic({
  
  component: () => import('../answer/index'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/scorerule",
        "name": "scorerule",
        "icon": "setting",
        "component": _dvaDynamic({
  
  component: () => import('../Scorerule/index'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/trade",
        "name": "trade",
        "icon": "solution",
        "component": _dvaDynamic({
  
  component: () => import('../Trade/index'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/paytrade",
        "name": "paytrade",
        "icon": "shop",
        "component": _dvaDynamic({
  
  component: () => import('../Paytrade/index'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/vip",
        "name": "vip",
        "icon": "user",
        "component": _dvaDynamic({
  
  component: () => import('../Vip/index'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/oper",
        "name": "oper",
        "icon": "key",
        "component": _dvaDynamic({
  
  component: () => import('../Oper/index'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": _dvaDynamic({
  
  component: () => import('../404'),
  LoadingComponent: require('/Users/jifa/work/webapp/Lgg/src/components/PageLoading/index').default,
}),
        "exact": true
      }
    ]
  }
];

export default function() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
