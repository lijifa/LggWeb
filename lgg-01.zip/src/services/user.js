import request from '@/utils/request';

export async function query() {
  return request('/vip/query');
}

export async function add() {
  return request('/vip/add');
}

export async function update() {
  return request('/vip/update');
}

export async function del() {
  return request('/vip/del');
}

export async function queryCurrent() {
  return request('/api/currentUser');
}
